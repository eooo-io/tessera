# @eooo-io/theme

The **token half** of the eooo design system — a [daisyUI 5](https://daisyui.com)
theme (Tailwind v4, CSS-first) expressed entirely in OKLCH. This is the single
source of truth for the *look*: TALL (Mary UI) and React (Tailwind) apps that
import it render identically, sharing only this CSS.

Ships two themes — `eooo-light` (default) and `eooo-dark` — plus a mobile-first
44px touch-target floor. No JavaScript, no build step, no component framework
baked in.

## Palette — "Petrol & Signal"

| Token | Role | Hex | OKLCH |
|-------|------|-----|-------|
| Abyss | darkest base | `#151C25` | `oklch(0.225 0.021 253)` |
| Petrol | primary · brand | `#035373` | `oklch(0.417 0.085 233)` |
| Cyan | accent · links | `#0A7EA6` | `oklch(0.556 0.108 230)` |
| Slate | neutral · muted text | `#6D898C` | `oklch(0.610 0.032 204)` |
| Mist | light surface | `#B7C6C7` | `oklch(0.815 0.016 202)` |
| Oxblood | deep / pressed danger | `#730F06` | `oklch(0.358 0.134 30)` |
| Signal | error · alert | `#D90404` | `oklch(0.557 0.227 29)` |
| Ember | warm accent · warning | `#F26A4B` | `oklch(0.686 0.174 34)` |

Reds are reserved for genuine signal; Ember bridges warning → error. Geometry is
near-rectangular (3px fields, 4px boxes). Primary/error button text is a soft
cool-gray rather than pure white.

## Install

GitHub Packages hosts this under the `@eooo-io` scope (npm scope must match the
GitHub owner). In the **consuming app**, add an `.npmrc`:

```
@eooo-io:registry=https://npm.pkg.github.com
```

then:

```bash
npm install @eooo-io/theme
```

> Installing from GitHub Packages requires auth even for reads — a personal
> access token with `read:packages` in your `~/.npmrc`, or `NODE_AUTH_TOKEN` in
> CI.

## Use

In your `app.css` (Tailwind v4, CSS-first — no `tailwind.config.js`):

```css
@import "tailwindcss";
@plugin "daisyui";
@import "@eooo-io/theme";
```

That's it. Because Mary UI ships no CSS of its own, every daisyUI/Blade component
inherits these tokens automatically. Set the active theme on `<html>`:

```html
<html data-theme="eooo-light">   <!-- or eooo-dark -->
```

## Publishing (maintainers)

Publishing to GitHub Packages needs a **classic** PAT with `write:packages`
(fine-grained tokens are not supported by GitHub Packages). Locally:

```bash
export NODE_AUTH_TOKEN=ghp_xxx        # classic PAT, write:packages
npm publish
```

Or let CI do it — the included workflow publishes on any `v*` tag using the
built-in `GITHUB_TOKEN` (no PAT to store):

```bash
npm version patch      # bumps package.json + creates the git tag
git push --follow-tags
```

## Versioning is the governance

The published-package boundary *is* how the system stays consistent. Change a
token here, bump the version, and every consuming app picks it up on the next
`npm update`. Don't fork tokens into apps — change them here.

## See also

- **`eooo/ui`** — the Blade component half (thin wrappers over Mary UI). Requires
  this package as a peer for styling.
